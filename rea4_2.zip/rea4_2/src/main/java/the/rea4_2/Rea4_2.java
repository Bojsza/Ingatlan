package the.rea4_2; // Ez a kód egy adott csomagban van elhelyezve, the.rea4_2 néven.

//Ezek az importok szükségesek a Swing GUI komponensek és eseménykezelők használatához.
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*; // sql adatbázis műveletekhez

//Ez az osztály tartalmazza az alkalmazás fő logikáját és a GUI felépítését.
// Az ingatlan adatait tároló változók deklarálása
public class Rea4_2 { 
    private int refszam;
    private String tipus;
    private String telepules;
    private int alapter_nm;
    private int szobak;
    private int ar;
    private String parkolo;
    private String emelet;
    private int erkely_nm;
    private int szintek;
    private int telek_nm;
    private String leiras;
    private String statusz;
    
    //Konstruktor az ingatlan adatainak inicializálásához
    //Az osztály konstruktora az ingatlan adatainak inicializálására szolgál.
    public Rea4_2(int refszam, String tipus, String telepules, int alapter_nm, int szobak, int ar, String parkolo, String emelet, int erkely_nm, int szintek, int telek_nm, String leiras, String statusz) {
        this.refszam = refszam;
        this.tipus = tipus;
        this.telepules = telepules;
        this.alapter_nm = alapter_nm;
        this.szobak = szobak;
        this.ar = ar;
        this.parkolo = parkolo;
        this.emelet = emelet;
        this.erkely_nm = erkely_nm;
        this.szintek = szintek;
        this.telek_nm = telek_nm;
        this.leiras = leiras;
        this.statusz = statusz;
    }
    
    // Main metódus az alkalmazás indításához
    // Az alkalmazás belépési pontja. Ez hozza létre az alkalmazás fő osztályát és hívja meg a GUI létrehozásához és megjelenítéséhez szükséges függvényt.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Új példány létrehozása az ingatlan osztályból
            Rea4_2 app = new Rea4_2(1, "haz", "Budapest", 100, 5, 2000000, "utca", "foldszint", 20, 2, 500, "nagyon szep lakas", "elado");
            // GUI létrehozása és megjelenítése
            app.createAndShowGUI();          
        });
    }

    //A connect() metódus helyesnek tűnik, beállítja a JDBC URL-t, a felhasználónevet és a jelszót, majd megpróbálja betölteni a MySQL JDBC drivert és létrehozni a kapcsolatot az adatbázissal.
    private Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/real_estate"; // JDBC URL
        String user = "root"; // XAMPP alapértelmezett felhasználóneve
        String password = ""; // XAMPP alapértelmezett jelszava (nekünk most nem jelszóvédett)
           /*
            
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }  // már nem szükséges a legtöbb modern JDBC verzió esetén, mivel az újabb JDBC implementációk automatikusan regisztrálják magukat. 
        */
        return DriverManager.getConnection(url, user, password);
    }
    
    
    
    // A főablak létrehozása és megjelenítése
    //Ez a metódus hozza létre és jeleníti meg a fő ablakot (JFrame-et), beállítja a gombokat és a táblázatot, valamint hozzáadja az eseménykezelőket a gombokhoz.
    private void createAndShowGUI() {
        // Új ablak létrehozása
        JFrame frame = new JFrame("REA - Ingatlankezelő rendszer");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(800, 600)); // Ablak méretének beállítása (800x600)

        // Gombok létrehozása
        // A kód létrehoz két gombot, egyet "Feltöltés" és egyet "Keresés" névvel.
        JButton uploadButton = new JButton("Feltöltés");
        JButton searchButton = new JButton("Keresés");
        // Táblázat inicializálása
        // A kód egy táblázatot hoz létre, amely a megjelenítendő adatokat tartalmazza.
        JTable table = new JTable();
        DefaultTableModel model = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
            return false; // Minden cella nem szerkeszthető falsenál, truenál szerkeszthető
            }
        };

        // Táblázat oszlopainak beállítása
        model.addColumn("Refszám");
        model.addColumn("Típus");
        model.addColumn("Település");
        model.addColumn("Alapterület");
        model.addColumn("Szobák száma");
        model.addColumn("Ár");
        model.addColumn("Státusz");
        table.setModel(model);
        
        // Adatok hozzáadása a táblázathoz        
        // addDataToTable(model); //adatbázis bekötésnél kiszedtem
        addDataFromDatabase(model);


        // Gombpanel létrehozása és gombok hozzáadása        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(uploadButton);
        buttonPanel.add(searchButton);

         // Frame-hez gombok és táblázat hozzáadása       
        frame.add(buttonPanel, BorderLayout.NORTH);
        // Táblázatot tartalmazó JScrollPane hozzáadása a frame-hez
        JScrollPane scrollPane = new JScrollPane(table); // Ez a JScrollPane lehetővé teszi a táblázat görgetését, ha az adatok több helyet foglalnak el, mint amennyi hely rendelkezésre áll az ablakban.
        frame.add(scrollPane, BorderLayout.CENTER);
        
        // Keresés gombra kattintás eseménykezelése
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Az új keresési ablak megjelenítése
                JOptionPane.showMessageDialog(null, "Dolgozunk rajta:)");
                //new SearchPage(frame, model); ----SearchPage class létrehozásától kezdve kell-------
            }
        });
        
        // Feltöltés gombra kattintás eseménykezelése        
        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Az új feltöltési ablak megjelenítése
                JOptionPane.showMessageDialog(null, "Dolgozunk rajta:)");
                //new UploadPage(frame, model); ----UploadPage class létrehozásától kezdve kell-------
            }
        });
        

        // Frame beállítása és megjelenítése
        frame.pack();
        frame.setVisible(true);
    }

    // Kapcsolódik az adatbázishoz és megpróbálja lekérdezni az "ingatlanok" tábla összes sorát, majd hozzáadja ezeket a sorokat a megadott DefaultTableModel-hoz.
    private void addDataFromDatabase(DefaultTableModel model) {
        try {
            Connection connection = connect();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM ingatlanok");

            while (resultSet.next()) {
                int refszam = resultSet.getInt("refszam");
                String tipus = resultSet.getString("tipus");
                String telepules = resultSet.getString("telepules");
                int alapter_nm = resultSet.getInt("alapter_nm");
                int szobak = resultSet.getInt("szobak");
                int ar = resultSet.getInt("ar");
                String statusz = resultSet.getString("statusz");

                model.addRow(new Object[]{refszam, tipus, telepules, alapter_nm, szobak, ar, statusz});
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // adatbázis bekötésnél kikerült:
    // Adatok hozzáadása a táblázathoz
    //Az addDataToTable metódus segítségével hozzáad egy sort az adatokkal a táblázathoz.
    /*private void addDataToTable(DefaultTableModel model) {
        model.addRow(new Object[]{refszam, tipus, telepules, alapter_nm, szobak, ar, statusz});
    }*/
}


// TOVÁBBBI CLASSOK:
/*SearchPage.java külön class-t packagen belül LÉTREHOZNI MAJD!---------------------------------
"
package the.rea4;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchPage {
    private JFrame frame;
    private JTextField refszamField;
    private JTextField tipusField;
    private JTextField telepulesField;
    private JTextField alapterField;
    private JTextField szobakField;
    private JTextField arField;
    private JTextField statuszField;
    private JTextField parkoloField;
    private JTextField emeletField;
    private JTextField erkelyField;
    private JTextField szintekField;
    private JTextField telekField;

    // Konstruktor a keresési ablak létrehozásához
    public SearchPage(JFrame parentFrame, DefaultTableModel tableModel) {
        frame = new JFrame("Ingatlan Keresése");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Panel létrehozása és beállítása
        JPanel panel = new JPanel(new GridLayout(8, 2, 5, 5));

        // Mezők és címkék létrehozása
        JLabel refszamLabel = new JLabel("Refszám:");
        refszamField = new JTextField();
        JLabel tipusLabel = new JLabel("Típus:");
        tipusField = new JTextField();
        JLabel telepulesLabel = new JLabel("Település:");
        telepulesField = new JTextField();
        JLabel alapterLabel = new JLabel("Alapterület:");
        alapterField = new JTextField();
        JLabel szobakLabel = new JLabel("Szobák száma:");
        szobakField = new JTextField();
        JLabel arLabel = new JLabel("Ár:");
        arField = new JTextField();
        JLabel statuszLabel = new JLabel("Státusz:");
        statuszField = new JTextField();
        JLabel parkoloLabel = new JLabel("Parkoló:");
        parkoloField = new JTextField();
        JLabel emeletLabel = new JLabel("Emelet:");
        emeletField = new JTextField();
        JLabel erkelyLabel = new JLabel("Erkély:");
        erkelyField = new JTextField();
        JLabel szintekLabel = new JLabel("Szintek:");
        szintekField = new JTextField();
        JLabel telekLabel = new JLabel("Telek:");
        telekField = new JTextField();
        
        // Mezők és címkék hozzáadása a panelhez
        panel.add(refszamLabel);
        panel.add(refszamField);
        panel.add(tipusLabel);
        panel.add(tipusField);
        panel.add(telepulesLabel);
        panel.add(telepulesField);
        panel.add(alapterLabel);
        panel.add(alapterField);
        panel.add(szobakLabel);
        panel.add(szobakField);
        panel.add(arLabel);
        panel.add(arField);
        panel.add(statuszLabel);
        panel.add(statuszField);
        panel.add(parkoloLabel);
        panel.add(parkoloField);
        panel.add(emeletLabel);
        panel.add(emeletField);
        panel.add(erkelyLabel);
        panel.add(erkelyField);
        panel.add(szintekLabel);
        panel.add(szintekField);
        panel.add(telekLabel);
        panel.add(telekField);
        
        // Gombok létrehozása és hozzáadása
        JButton searchButton = new JButton("Keresés");
        JButton homeButton = new JButton("Home");
        
        // Keresés gomb eseménykezelője
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Keresés funkció
                // Implementáld a keresési logikát itt!!!!!!!!
            }
        });

        // Home gomb eseménykezelője
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                parentFrame.setVisible(true); // A főablak újra láthatóvá tétele
            }
        });

        // Gombok hozzáadása a panelhez        
        panel.add(searchButton);
        panel.add(homeButton);

        // Panel hozzáadása a frame-hez       
        frame.add(panel);
        frame.pack();
        frame.setLocationRelativeTo(parentFrame); // Az új ablak középre helyezése
        frame.setVisible(true);
    }
}
"

TOVÁBBÁ:
UploadPage.java külön class-t packagen belül LÉTREHOZNI MAJD!---------------------------------
"
package the.rea4;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class UploadPage {
    private JFrame frame;
    private JTextField refszamField;
    private JTextField tipusField;
    private JTextField telepulesField;
    private JTextField alapterField;
    private JTextField szobakField;
    private JTextField arField;
    private JTextField statuszField;
    private JTextField parkoloField;
    private JTextField emeletField;
    private JTextField erkelyField;
    private JTextField szintekField;
    private JTextField telekField;

    // Konstruktor az adatfeltöltő ablak létrehozásához
    public UploadPage(JFrame parentFrame, DefaultTableModel tableModel) {
        frame = new JFrame("Ingatlan Feltöltése");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Panel létrehozása és beállítása
        JPanel panel = new JPanel(new GridLayout(8, 2, 5, 5));

        // Mezők és címkék létrehozása
        JLabel refszamLabel = new JLabel("Refszám:");
        refszamField = new JTextField();
        JLabel tipusLabel = new JLabel("Típus:");
        tipusField = new JTextField();
        JLabel telepulesLabel = new JLabel("Település:");
        telepulesField = new JTextField();
        JLabel alapterLabel = new JLabel("Alapterület:");
        alapterField = new JTextField();
        JLabel szobakLabel = new JLabel("Szobák száma:");
        szobakField = new JTextField();
        JLabel arLabel = new JLabel("Ár:");
        arField = new JTextField();
        JLabel statuszLabel = new JLabel("Státusz:");
        statuszField = new JTextField();
        JLabel parkoloLabel = new JLabel("Parkoló:");
        parkoloField = new JTextField();
        JLabel emeletLabel = new JLabel("Emelet:");
        emeletField = new JTextField();
        JLabel erkelyLabel = new JLabel("Erkély:");
        erkelyField = new JTextField();
        JLabel szintekLabel = new JLabel("Szintek:");
        szintekField = new JTextField();
        JLabel telekLabel = new JLabel("Telek:");
        telekField = new JTextField();

        // Mezők és címkék hozzáadása a panelhez        
        panel.add(refszamLabel);
        panel.add(refszamField);
        panel.add(tipusLabel);
        panel.add(tipusField);
        panel.add(telepulesLabel);
        panel.add(telepulesField);
        panel.add(alapterLabel);
        panel.add(alapterField);
        panel.add(szobakLabel);
        panel.add(szobakField);
        panel.add(arLabel);
        panel.add(arField);
        panel.add(statuszLabel);
        panel.add(statuszField);
        panel.add(parkoloLabel);
        panel.add(parkoloField);
        panel.add(emeletLabel);
        panel.add(emeletField);
        panel.add(erkelyLabel);
        panel.add(erkelyField);
        panel.add(szintekLabel);
        panel.add(szintekField);
        panel.add(telekLabel);
        panel.add(telekField);

        // Gombok létrehozása és hozzáadása        
        JButton uploadButton = new JButton("Feltöltés");
        JButton homeButton = new JButton("Home");

        // Feltöltés gomb eseménykezelője        
        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Feltöltés funkció
                // Implementáld a feltöltési logikát itt!!!!!!!!!!!
                addDataToTable(tableModel);
                frame.dispose();
                parentFrame.setVisible(true);
            }
        });
        
        // Home gomb eseménykezelője        
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                parentFrame.setVisible(true); // A főablak újra láthatóvá tétele
            }
        });

        // Gombok hozzáadása a panelhez        
        panel.add(uploadButton);
        panel.add(homeButton);

        // Panel hozzáadása a frame-hez        
        frame.add(panel);
        frame.pack();
        frame.setLocationRelativeTo(parentFrame); // Az új ablak középre helyezése
        frame.setVisible(true);
    }

    // Adatok hozzáadása a táblázathoz
    private void addDataToTable(DefaultTableModel model) {
        // Adatok hozzáadása a táblázathoz
        // Az adatokat a mezőkből kell kinyerni
        int refszam = Integer.parseInt(refszamField.getText());
        String tipus = tipusField.getText();
        String telepules = telepulesField.getText();
        int alapter_nm = Integer.parseInt(alapterField.getText());
        int szobak = Integer.parseInt(szobakField.getText());
        int ar = Integer.parseInt(arField.getText());
        String parkolo = parkoloField.getText();
        String emelet = emeletField.getText();
        int erkely_nm = Integer.parseInt(erkelyField.getText());
        int szintek = Integer.parseInt(szintekField.getText());
        int telek_nm = Integer.parseInt(telekField.getText());
        String leiras = ""; // Megjegyzés: Ez a mező nincs elérhető a feltöltés oldalon, így itt nem állítjuk be
        String statusz = statuszField.getText();
        
        // Az adatok hozzáadása a táblázathoz
        model.addRow(new Object[]{refszam, tipus, telepules, alapter_nm, szobak, ar, parkolo, emelet, erkely_nm, szintek, telek_nm, leiras, statusz});
    }
}
"

*/

/*
az alap POM fájl tartalma:

<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <groupId>the</groupId>
    <artifactId>rea4_2</artifactId>
    <version>1.0-SNAPSHOT</version>
    <packaging>jar</packaging>
    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <exec.mainClass>the.rea4_2.Rea4_2</exec.mainClass>
    </properties>
</project>

---plusz módosítás:

  <dependencies>
        <dependency>
            <groupId>the</groupId>
            <artifactId>mysql-connector-j</artifactId>
            <version>8.3.0</version> <!-- Actual version may vary -->
        </dependency>
    </dependencies>

*/