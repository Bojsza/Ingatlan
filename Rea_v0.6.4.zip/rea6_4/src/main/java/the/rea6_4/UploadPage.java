package the.rea6_4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UploadPage extends JPanel { 
    private JLabel refszamLabel;
    private JComboBox<String> tipusField;
    private JTextField telepulesField;
    private JTextField alapterField;
    private JTextField szobakField;
    private JTextField arField;
    private JComboBox<String> parkoloField;
    private JComboBox<String> emeletField;
    private JTextField erkelyField;
    private JTextField szintekField;
    private JTextField telekField;
    private JComboBox<String> statuszField;
    private JTextArea leirasField; 
    
    private CardLayout cardLayout;
    private JPanel cardPanel;
    private Rea6_4 mainApp;

    public UploadPage(CardLayout cardLayout, JPanel cardPanel, Rea6_4 mainApp) {
        this.cardLayout = cardLayout;
        this.cardPanel = cardPanel;
        this.mainApp = mainApp;

        setLayout(new GridLayout(14, 1)); // 14 sor, 1 oszlop

        // Beszúrjuk a referencia számot a címkébe
        refszamLabel = new JLabel("Referencia szám: ");
        add(refszamLabel);
        refreshRefszam();
        // beviteli mezők és felhasználói instrukciók
        addField("Típus:", tipusField = new JComboBox<>(new String[]{"ház", "lakás"}), 150, "Válassz típust! Ház vagy lakás?");
        addField("Település:", telepulesField = new JTextField(), 150, "Írd be a települést. Ügyelj a pontosságra és a helyesírásra!");
        addField("Alapterület (nm):", alapterField = new JTextField(), 150, "Add meg az alapterületet négyzetméterben!");
        addField("Szobák száma:", szobakField = new JTextField(), 150, "Add meg a szobák számát!");
        addField("Ár:", arField = new JTextField(), 150, "Add meg az árat forintban!");
        addField("Parkoló:", parkoloField = new JComboBox<>(new String[]{"udvari beálló", "utca", "közterület", "önálló garázs", "nincs"}), 150, "Válassz parkolótípust!");
        addField("Emelet:", emeletField = new JComboBox<>(new String[]{"szuterén", "földszint", "félemelet", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "további emelet"}), 150, "Válassz emeletet! (ahol a bejárati ajtó van)");
        addField("Erkély méret (nm):", erkelyField = new JTextField(), 150, "Add meg az erkély méretét négyzetméterben! (Ha nincs erkély akkor: 0-t írj!)");
        addField("Épület szintjeinek száma:", szintekField = new JTextField(), 150, "Add meg az épület szintjeinek számát!");
        addField("Telek területe (nm):", telekField = new JTextField(), 150, "Add meg a telek méretét négyzetméterben (Ha az ingatlanhoz nem tartozik telek akkor: 0-t írj!)");
        addField("Státusz:", statuszField = new JComboBox<>(new String[]{"eladó", "eladva", "ügyintézés alatt"}), 150, "Válassz státuszt!");
        addField("Leírás:", leirasField = new JTextArea(3, 50), 400, "Írd le részletesen az ingatlan leírását"); 

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        
        JButton uploadButton = new JButton(" Feltöltés az adatbázisba");
        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Adatok lekérése a mezőkből
                int refszam = Integer.parseInt(refszamLabel.getText().split(": ")[1]);
                String tipus = (String) tipusField.getSelectedItem();
                String telepules = telepulesField.getText();
                int alapter = alapterField.getText().equals("") ? -1 : Integer.parseInt(alapterField.getText()); // ezen short hand if-ek a hibaüzenet működéséhez kellenek...hogy üres int-ek ne lehessenek
                int szobak = szobakField.getText().equals("") ? -1 : Integer.parseInt(szobakField.getText());
                int ar = arField.getText().equals("") ? -1 : Integer.parseInt(arField.getText());
                String parkolo = (String) parkoloField.getSelectedItem();
                String emelet = (String) emeletField.getSelectedItem();
                int erkely = erkelyField.getText().equals("") ? -1 :  Integer.parseInt(erkelyField.getText());
                int szintek = szintekField.getText().equals("") ? -1 : Integer.parseInt(szintekField.getText());
                int telek = telekField.getText().equals("") ? -1 : Integer.parseInt(telekField.getText());
                String statusz = (String) statuszField.getSelectedItem();
                String leiras = leirasField.getText(); 

                // Új adat beszúrása az adatbázisba és üzenetek
                if (insertData(refszam, tipus, telepules, alapter, szobak, ar, parkolo, emelet, erkely, szintek, telek, statusz, leiras)) {
                    JOptionPane.showMessageDialog(null, "Sikeresen hozzáadva az adatbázishoz", "Sikeres feltöltés", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Nem sikerült hozzáadni az új ingatlant az adatbázishoz", "Sikertelen feltöltés", JOptionPane.ERROR_MESSAGE);
                }

                // Tiszta állapot visszaállítása
                clearFields();
                // Frissítjük a refszámot az új ingatlanhoz
                refreshRefszam();
                // Visszalépés az első oldalra és táblázat frissítése
                cardLayout.show(cardPanel, "table");
                mainApp.addDataFromDatabase(); // Frissítsük a táblázatot a kezdőoldalon
            }
        });
        buttonPanel.add(uploadButton, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.NORTH);
       
        
        JButton homeButton = new JButton("Vissza a kezdő oldalra");
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "table"); // Az első oldalra váltás
            }
        });
        buttonPanel.add(homeButton, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.NORTH);
    }

    // GUI: Segédfüggvény egy címke-beviteli mező pár hozzáadásához és a hover üzenetekhez
    private void addField(String labelText, JComponent field, int fieldWidth, String tooltipText) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel label = new JLabel(labelText);
        label.setPreferredSize(new Dimension(150, 25));
        field.setPreferredSize(new Dimension(fieldWidth, 25));
        panel.add(label);
        panel.add(field);
        add(panel);
        label.setToolTipText(tooltipText);
    }

    // Adatok beszúrása az adatbázisba
    private boolean insertData(int refszam, String tipus, String telepules, int alapter, int szobak, int ar, String parkolo, String emelet, int erkely, int szintek, int telek, String statusz, String leiras) {
        // Ellenőrizzük az érvénytelen adatokat / hibaüzenetek
        if (alapter <= 10  || alapter > 2147483646 || szobak <= 0 || szobak > 500 ||  ar <= 10000 || ar >  2147483646 || erkely < 0 || erkely > 500 || szintek <= 0 || szintek > 100 || telek < 0 || telek > 2147483646 || telepules.isEmpty() || leiras.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Kérlek töltsd ki az összes mezőt megfelelően!", "Érvénytelen adatok", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try { 
            Connection connection = connect();
            String query = "INSERT INTO ingatlanok (refszam, tipus, telepules, alapter_nm, szobak, ar, parkolo, emelet, erkely_nm, szintek, telek_nm, statusz, leiras) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, refszam);
            statement.setString(2, tipus);
            statement.setString(3, telepules);
            statement.setInt(4, alapter);
            statement.setInt(5, szobak);
            statement.setInt(6, ar);
            statement.setString(7, parkolo);
            statement.setString(8, emelet);
            statement.setInt(9, erkely);
            statement.setInt(10, szintek);
            statement.setInt(11, telek);
            statement.setString(12, statusz);
            statement.setString(13, leiras); 
            statement.executeUpdate();
            statement.close();
            connection.close();
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Kapcsolódik az adatbázishoz
    
    private Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/real_estate"; 
        String user = "root"; 
        String password = ""; 
        return DriverManager.getConnection(url, user, password);
    }


    // Az adatbázisból lekérjük a soron következő elsődleges kulcs értékét a beillesztendő refszámnak
    private void refreshRefszam() {
        try {
            Connection connection = connect();
            String query = "SELECT MAX(refszam) FROM ingatlanok";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                int nextRefszam = resultSet.getInt(1) + 1;
                refszamLabel.setText("Referencia szám: " + nextRefszam);
            }
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Törli a beviteli mezők tartalmát
    private void clearFields() {
        telepulesField.setText("");
        alapterField.setText("");
        szobakField.setText("");
        arField.setText("");
        erkelyField.setText("");
        szintekField.setText("");
        telekField.setText("");
        leirasField.setText(""); 
    }
}

