package the.rea6_4; // Fejlesztés folyamatban 230. sor és 247. sor-nál

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class SearchPage extends JPanel {

    // A keresési oldalon lévő elemek deklarációja
    private JComboBox<String> tipusField;
    private JTextField minAlapterField;
    private JTextField maxAlapterField;
    private JTextField minSzobakField;
    private JTextField maxSzobakField;
    private JTextField minArField;
    private JTextField maxArField;
    private JComboBox<String> statuszField;
    private JComboBox<String> parkoloField;
    private JComboBox<String> emeletField;
    private JTextField minErkelyField;
    private JTextField maxErkelyField;
    private JTextField minSzintekField;
    private JTextField maxSzintekField;
    private JTextField minTelekField;
    private JTextField maxTelekField;

    // Konstruktor, amely inicializálja a keresési oldalt
    public SearchPage(CardLayout cardLayout, JPanel cardPanel) {
        setLayout(new GridLayout(18, 2)); // 18 sor, 2 oszlop

        // Típus
        JLabel tipusLabel = new JLabel("Típus:");
        tipusField = new JComboBox<>(new String[]{"minden", "ház", "lakás"});
        add(tipusLabel);
        add(tipusField);

        // Alapterület
        JLabel alapterLabel = new JLabel("Alapterület:");
        minAlapterField = new JTextField();
        setPlaceholder(minAlapterField, "minimum nm");
        maxAlapterField = new JTextField();
        setPlaceholder(maxAlapterField, "maximum nm");
        add(alapterLabel);
        add(new JPanel());
        add(minAlapterField);
        add(maxAlapterField);

        // Szobák száma
        JLabel szobakLabel = new JLabel("Szobák száma:");
        minSzobakField = new JTextField();
        setPlaceholder(minSzobakField, "minimum szobaszám");
        maxSzobakField = new JTextField();
        setPlaceholder(maxSzobakField, "maximum szobaszám");
        add(szobakLabel);
        add(new JPanel());
        add(minSzobakField);
        add(maxSzobakField);

        // Ár
        JLabel arLabel = new JLabel("Ár:");
        minArField = new JTextField();
        setPlaceholder(minArField, "minimum ár");
        maxArField = new JTextField();
        setPlaceholder(maxArField, "maximum ár");
        add(arLabel);
        add(new JPanel());
        add(minArField);
        add(maxArField);

        // Státusz
        JLabel statuszLabel = new JLabel("Státusz:");
        statuszField = new JComboBox<>(new String[]{"minden", "eladó", "eladva", "ügyintézés alatt"});
        add(statuszLabel);
        add(statuszField);

        // Parkoló
        JLabel parkoloLabel = new JLabel("Parkoló:");
        parkoloField = new JComboBox<>(new String[]{"minden", "nincs","bármilyen parkolóval", "udvari beálló", "utca", "közterület", "önálló garázs" });
        add(parkoloLabel);
        add(parkoloField);

        // Emelet
        JLabel emeletLabel = new JLabel("Emelet:");
        emeletField = new JComboBox<>(new String[]{"minden","1 vagy alatta ", "2 vagy fölötte", "szuterén", "földszint", "félemelet", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "10 fölötti emeletek"});
        add(emeletLabel);
        add(emeletField);

        // Erkély
        JLabel erkelyLabel = new JLabel("Erkély mérete:");
        minErkelyField = new JTextField();
        setPlaceholder(minErkelyField, "minimum nm");
        maxErkelyField = new JTextField();
        setPlaceholder(maxErkelyField, "maximum nm");
        add(erkelyLabel);
        add(new JPanel());
        add(minErkelyField);
        add(maxErkelyField);

        // Szintek
        JLabel szintekLabel = new JLabel("Épület szintjeinek száma:");
        minSzintekField = new JTextField();
        setPlaceholder(minSzintekField, "minimum szintek száma");
        maxSzintekField = new JTextField();
        setPlaceholder(maxSzintekField, "maximum szintek száma");
        add(szintekLabel);
        add(new JPanel());
        add(minSzintekField);
        add(maxSzintekField);

        // Telek
        JLabel telekLabel = new JLabel("Telek:");
        minTelekField = new JTextField();
        setPlaceholder(minTelekField, "minimum telek nm");
        maxTelekField = new JTextField();
        setPlaceholder(maxTelekField, "maximum telek nm");
        add(telekLabel);
        add(new JPanel());
        add(minTelekField);
        add(maxTelekField);

        setupSearchButton();

        // Home gomb és eseménykezelője...
        
        JButton homeButton = new JButton("Vissza a kezdő oldalra");
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "table"); // Az első oldalra váltás
            }
        });
        add(homeButton); //home gomb hozzáadása
    }

    // Placeholder beállítása JTextField-hez
    private void setPlaceholder(JTextField textField, String placeholder) {
        textField.setForeground(Color.GRAY);
        textField.setText(placeholder);
        textField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textField.getText().equals(placeholder)) {
                    textField.setText("");
                    textField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textField.getText().isEmpty()) {
                    textField.setForeground(Color.GRAY);
                    textField.setText(placeholder);
                }
            }
        });
    }

    // Keresési logika megvalósítása...
    private void search() {
        // Gyűjtsük össze az összes keresési feltételt
        String tipus = (String) tipusField.getSelectedItem();
        String minAlapter = minAlapterField.getText();
        String maxAlapter = maxAlapterField.getText();
        String minSzobak = minSzobakField.getText();
        String maxSzobak = maxSzobakField.getText();
        String minAr = minArField.getText();
        String maxAr = maxArField.getText();
        String statusz = (String) statuszField.getSelectedItem();
        String parkolo = (String) parkoloField.getSelectedItem();
        String emelet = (String) emeletField.getSelectedItem();
        String minErkely = minErkelyField.getText();
        String maxErkely = maxErkelyField.getText();
        String minSzintek = minSzintekField.getText();
        String maxSzintek = maxSzintekField.getText();
        String minTelek = minTelekField.getText();
        String maxTelek = maxTelekField.getText();

        // Az adatbázisból való keresés meghívása
        Database.search(tipus, minAlapter, maxAlapter, minSzobak, maxSzobak, minAr, maxAr, statusz, parkolo, emelet, minErkely, maxErkely, minSzintek, maxSzintek, minTelek, maxTelek);
    }

    // Keresés gomb eseménykezelőjének beállítása
    private void setupSearchButton() {
        JButton searchButton = new JButton("Keresés az adatbázisban");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                search(); // Hívjuk meg a keresési logika metódust
            }
        });
        add(searchButton);// keresés gomb hozzáadása
    }
}

class Database {
    // Metódus az adatbázis kapcsolat létrehozására
    
    public static Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/real_estate"; 
        String user = "root"; 
        String password = ""; 
        return DriverManager.getConnection(url, user, password);
    }
    

    // Metódus az adatbázisból való keresésre
    public static void search(String tipus, String minAlapter, String maxAlapter, String minSzobak, String maxSzobak, String minAr, String maxAr, String statusz, String parkolo, String emelet, String minErkely, String maxErkely, String minSzintek, String maxSzintek, String minTelek, String maxTelek) {
        try {
            Connection conn = connect();

            // Létrehozunk egy SQL lekérdezést
            String sql = "SELECT refszam FROM ingatlanok WHERE ";

            // Ha a típus "minden", akkor minden típusú ingatlant visszünk át
            if (tipus.equals("minden")) {
                sql += "(tipus = 'ház' OR tipus = 'lakás') AND ";
            }
            // Ha a típus "ház", akkor csak a ház típusú ingatlanokat szűrjük
            else if (tipus.equals("ház")) {
                sql += "tipus = 'ház' AND ";
            }
            // Ha a típus "lakás", akkor csak a lakás típusú ingatlanokat szűrjük
            else if (tipus.equals("lakás")) {
                sql += "tipus = 'lakás' AND ";
            }
            // és így tovább...
            
            //FEJLESZTÉS FOLYAMATBAN:
            // további input mezőkben foglalt értékek alapján adatbázis lekérdezések végrehajtási feltételeinek kidolgozása

            
            
            // Utolsó "AND" eltávolítása a felesleges feltétel miatt
            sql = sql.substring(0, sql.length() - 5);

            // A lekérdezés futtatása
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            // Az eredmény feldolgozása
            while (rs.next()) {
                int refszam = rs.getInt("refszam");
                
                // Az elsődleges kulcsokat jegyezzük meg és jelenitsük meg (most még csak a konzolon)
                System.out.println("Elsődleges kulcs: " + refszam);
            
                // FEJLESZTÉS FOLYAMATBAN
                // ki kell dolgozni a találatok GUI megjelenítésének módját még   
            }

            // Bezárjuk a kapcsolatot és a lekérdezést
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}    
