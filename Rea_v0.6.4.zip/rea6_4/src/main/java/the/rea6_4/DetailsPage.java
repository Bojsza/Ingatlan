package the.rea6_4;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class DetailsPage extends JPanel {
    private int refszam;
    private Rea6_4 rea6;
    private JLabel refszamLabel;
    private JLabel tipusLabel;
    private JLabel leirasLabel;
    private JLabel telepulesLabel;
    private JLabel alapterLabel;
    private JLabel szobakLabel;
    private JLabel arLabel;
    private JLabel parkoloLabel;
    private JLabel emeletLabel;
    private JLabel erkelyLabel;
    private JLabel szintekLabel;
    private JLabel telekLabel;
    private JLabel statuszLabel;

    public DetailsPage(int refszam, Rea6_4 rea6) {
        this.refszam = refszam;
        this.rea6 = rea6;
        setLayout(new BorderLayout()); // BorderLayout

        JPanel dataPanel = new JPanel(new GridLayout(0, 2, 10, 5)); // 2 oszlopos GridLayout a fő adatoknak
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER)); // A gomboknak
        JPanel bottomPanel = new JPanel(new BorderLayout()); // Az alsó paneleknek

        try {
            // Adatbáziskapcsolat létrehozása
            Connection connection = connect();
            Statement statement = connection.createStatement();
            // Adatbáziskapcsolat létrehozása
            ResultSet resultSet = statement.executeQuery("SELECT * FROM ingatlanok WHERE refszam = " + refszam);
            
            // Ha találtunk eredményt
            if (resultSet.next()) {
                addLabel(dataPanel, "Referenciaszám:");
                refszamLabel = new JLabel(resultSet.getString("refszam"));
                dataPanel.add(refszamLabel);

                addLabel(dataPanel, "Típus:");
                tipusLabel = new JLabel(resultSet.getString("tipus"));
                dataPanel.add(tipusLabel);

                addLabel(dataPanel, "Település:");
                telepulesLabel = new JLabel(resultSet.getString("telepules"));
                dataPanel.add(telepulesLabel);

                addLabel(dataPanel, "<html>Alapterület (m<sup>2</sup>):</html>");
                alapterLabel = new JLabel(resultSet.getString("alapter_nm"));
                dataPanel.add(alapterLabel);

                addLabel(dataPanel, "Szobák száma:");
                szobakLabel = new JLabel(resultSet.getString("szobak"));
                dataPanel.add(szobakLabel);

                addLabel(dataPanel, "Ár:");
                arLabel = new JLabel(resultSet.getString("ar"));
                dataPanel.add(arLabel);

                addLabel(dataPanel, "Parkoló:");
                parkoloLabel = new JLabel(resultSet.getString("parkolo"));
                dataPanel.add(parkoloLabel);

                addLabel(dataPanel, "Emelet:");
                emeletLabel = new JLabel(resultSet.getString("emelet"));
                dataPanel.add(emeletLabel);

                addLabel(dataPanel, "<html>Erkély mérete (m<sup>2</sup>):</html>");
                erkelyLabel = new JLabel(resultSet.getString("erkely_nm"));
                dataPanel.add(erkelyLabel);

                addLabel(dataPanel, "Épület szintjeinek száma:");
                szintekLabel = new JLabel(resultSet.getString("szintek"));
                dataPanel.add(szintekLabel);

                addLabel(dataPanel, "<html>Telek területe (m<sup>2</sup>):</html>");
                telekLabel = new JLabel(resultSet.getString("telek_nm"));
                dataPanel.add(telekLabel);

                addLabel(dataPanel, "Leírás:");
                leirasLabel = new JLabel(resultSet.getString("leiras"));
                dataPanel.add(leirasLabel);

                // Státusz label hozzáadása
                addLabel(dataPanel, "Státusz:");
                statuszLabel = new JLabel(resultSet.getString("statusz"));
                dataPanel.add(statuszLabel);
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Gombok hozzáadása a gombpanelhez
        JButton editButton = new JButton("Szerkesztés");
        JButton statusButton = new JButton("Státusz váltás");
        buttonPanel.add(editButton);
        buttonPanel.add(statusButton);

        // Home gomb hozzáadása az alsó panelhez
        JButton homeButton = new JButton("Vissza a kezdő oldalra");
        homeButton.addActionListener(e -> {
            CardLayout cardLayout = (CardLayout) getParent().getLayout();
            cardLayout.show(getParent(), "table");
            rea6.addDataFromDatabase();
        });
        bottomPanel.add(homeButton, BorderLayout.SOUTH);

        // Az alsó panelek hozzáadása a fő panelhez
        add(dataPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.NORTH);
        add(bottomPanel, BorderLayout.SOUTH);

        // Státuszváltás gomb eseménykezelése és üzenetek
        statusButton.addActionListener(e -> {
            JComboBox<String> statusComboBox = new JComboBox<>(new String[]{"Eladó", "Eladva", "Ügyintézés alatt"});
            JPanel panel = new JPanel();
            panel.add(new JLabel("Válasszon új státuszt:"));
            panel.add(statusComboBox);

            int result = JOptionPane.showOptionDialog(
                    null,
                    panel,
                    "Státusz váltás",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    new String[]{"Mentés", "Mégsem"},
                    "default"
            );

            if (result == JOptionPane.OK_OPTION) {
                String selectedStatus = (String) statusComboBox.getSelectedItem();
                updateStatus(selectedStatus);
            }
        });

        editButton.addActionListener(e -> {
            // Felugró ablak létrehozása a szerkesztéshez
            JComboBox<String> tipusCombo = new JComboBox<>(new String[]{"ház", "lakás"});
            tipusCombo.setSelectedItem(tipusLabel.getText());
            JTextField telepulesField = new JTextField(telepulesLabel.getText());
            JTextField alapterField = new JTextField(alapterLabel.getText());
            JTextField szobakField = new JTextField(szobakLabel.getText());
            JTextField arField = new JTextField(arLabel.getText());
            JComboBox<String> parkoloCombo = new JComboBox<>(new String[]{"udvari beálló", "utca", "közterület", "önálló garázs", "nincs"});
            parkoloCombo.setSelectedItem(parkoloLabel.getText());
            JComboBox<String> emeletCombo = new JComboBox<>(new String[]{"szuterén", "földszint", "félemelet", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "további emelet"});
            emeletCombo.setSelectedItem(emeletLabel.getText());
            JTextField erkelyField = new JTextField(erkelyLabel.getText());
            JTextField szintekField = new JTextField(szintekLabel.getText());
            JTextField telekField = new JTextField(telekLabel.getText());
            JComboBox<String> statusCombo = new JComboBox<>(new String[]{"eladó", "eladva", "ügyintézés alatt"});
            statusCombo.setSelectedItem(statuszLabel.getText());
            JTextArea leirasField = new JTextArea(leirasLabel.getText());

            JPanel editPanel = new JPanel(new GridLayout(0, 2));
            editPanel.add(new JLabel("Típus:"));
            editPanel.add(tipusCombo);
            editPanel.add(new JLabel("Település:"));
            editPanel.add(telepulesField);
            editPanel.add(new JLabel("<html>Alapterület (m<sup>2</sup>):</html>"));
            editPanel.add(alapterField);
            editPanel.add(new JLabel("Szobák száma:"));
            editPanel.add(szobakField);
            editPanel.add(new JLabel("Ár:"));
            editPanel.add(arField);
            editPanel.add(new JLabel("Parkoló:"));
            editPanel.add(parkoloCombo);
            editPanel.add(new JLabel("Emelet:"));
            editPanel.add(emeletCombo);
            editPanel.add(new JLabel("<html>Erkély mérete (m<sup>2</sup>):</html>"));
            editPanel.add(erkelyField);
            editPanel.add(new JLabel("Épület szintjeinek száma:"));
            editPanel.add(szintekField);
            editPanel.add(new JLabel("<html>Telek területe (m<sup>2</sup>):</html>"));
            editPanel.add(telekField);
            editPanel.add(new JLabel("Státusz:"));
            editPanel.add(statusCombo);
            editPanel.add(new JLabel("Leírás:"));
            editPanel.add(leirasField);

            Object[] options = {"Mentés", "Mégsem"};

            int result = JOptionPane.showOptionDialog(null, editPanel,
                    "Adatok szerkesztése", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE,
                    null, options, options[0]);

            if (result == JOptionPane.YES_OPTION) {
                // Adatok frissítése az újonnan bevitt értékekkel
                String tipus = (String) tipusCombo.getSelectedItem();
                String telepules = telepulesField.getText();
                String alapterulet = alapterField.getText();
                String szobak = szobakField.getText();
                String ar = arField.getText();
                String parkolo = (String) parkoloCombo.getSelectedItem();
                String emelet = (String) emeletCombo.getSelectedItem();
                String erkely = erkelyField.getText();
                String szintek = szintekField.getText();
                String telek = telekField.getText();
                String status = (String) statusCombo.getSelectedItem();
                String leiras = leirasField.getText();
                
                if (updateData(tipus, telepules, alapterulet, szobak, ar, parkolo, emelet, erkely, szintek, telek, status, leiras)) {
                    JOptionPane.showMessageDialog(null, "Sikeres módosítás", "Siker", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Sikertelen módosítás, kérlek próbáld újra!", "Hiba", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
    
    // frissiti az adatokat az adatbázisban
    private boolean updateData(String tipus, String telepules, String alapterulet, String szobak, String ar, String parkolo, String emelet, String erkely, String szintek, String telek, String status, String leiras) {
        boolean success = false;
        try {
            Connection connection = connect();
            PreparedStatement preparedStatement = connection.prepareStatement(
                    "UPDATE ingatlanok SET tipus = ?, telepules = ?, alapter_nm = ?, szobak = ?, ar = ?, parkolo = ?, emelet = ?, erkely_nm = ?, szintek = ?, telek_nm = ?, statusz = ?, leiras = ?  WHERE refszam = ?");
            preparedStatement.setString(1, tipus);
            preparedStatement.setString(2, telepules);
            preparedStatement.setString(3, alapterulet);
            preparedStatement.setString(4, szobak);
            preparedStatement.setString(5, ar);
            preparedStatement.setString(6, parkolo);
            preparedStatement.setString(7, emelet);
            preparedStatement.setString(8, erkely);
            preparedStatement.setString(9, szintek);
            preparedStatement.setString(10, telek);
            preparedStatement.setString(11, status);
            preparedStatement.setString(12, leiras);
            preparedStatement.setInt(13, refszam);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

            // Az adatok frissítése a felületen
            tipusLabel.setText(tipus);
            telepulesLabel.setText(telepules);
            alapterLabel.setText(alapterulet);
            szobakLabel.setText(szobak);
            arLabel.setText(ar);
            parkoloLabel.setText(parkolo);
            emeletLabel.setText(emelet);
            erkelyLabel.setText(erkely);
            szintekLabel.setText(szintek);
            telekLabel.setText(telek);
            statuszLabel.setText(status);
            leirasLabel.setText(leiras);

            success = true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return success;
    }

    // Segédfüggvény az adatok hozzáadásához a panelhez
    private void addLabel(JPanel panel, String label) {
        JLabel jLabel = new JLabel(label);
        jLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(jLabel);
    }

    // Adatbázis frissítése az új státusszal
    private void updateStatus(String newStatus) {
        try {
            Connection connection = connect();
            PreparedStatement preparedStatement = connection.prepareStatement("UPDATE ingatlanok SET statusz = ? WHERE refszam = ?");
            preparedStatement.setString(1, newStatus);
            preparedStatement.setInt(2, refszam);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

            // Az adatbázis frissítése után újra lekérdezzük az adatokat és frissítjük a státusz label értékét
            Connection connectionRefresh = connect();
            Statement statementRefresh = connectionRefresh.createStatement();
            ResultSet resultSetRefresh = statementRefresh.executeQuery("SELECT * FROM ingatlanok WHERE refszam = " + refszam);

            if (resultSetRefresh.next()) {
                statuszLabel.setText(resultSetRefresh.getString("statusz"));
            }

            resultSetRefresh.close();
            statementRefresh.close();
            connectionRefresh.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/real_estate"; 
        String user = "root"; 
        String password = ""; 
        return DriverManager.getConnection(url, user, password);
    }
}
