package the.rea5_3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UploadPage extends JPanel {
    private JTextField refszamField;
    private JTextField tipusField;
    private JTextField telepulesField;
    private JTextField alapterField;
    private JTextField szobakField;
    private JTextField arField;
    private JTextField statuszField;
    private JTextField parkoloField;
    private JTextField emeletField;
    private JTextField erkelyField;
    private JTextField szintekField;
    private JTextField telekField;

    private CardLayout cardLayout;
    private JPanel cardPanel;
    private Rea5_3 mainApp;

    public UploadPage(CardLayout cardLayout, JPanel cardPanel, Rea5_3 mainApp) {
        this.cardLayout = cardLayout;
        this.cardPanel = cardPanel;
        this.mainApp = mainApp;

        setLayout(new GridLayout(8, 2)); // 8 sor, 2 oszlop

        JLabel refszamLabel = new JLabel("Refszám:");
        refszamField = new JTextField();
        add(refszamLabel);
        add(refszamField);

        JLabel tipusLabel = new JLabel("Típus:");
        tipusField = new JTextField();
        add(tipusLabel);
        add(tipusField);

        JLabel telepulesLabel = new JLabel("Település:");
        telepulesField = new JTextField();
        add(telepulesLabel);
        add(telepulesField);

        JLabel alapterLabel = new JLabel("Alapterület:");
        alapterField = new JTextField();
        add(alapterLabel);
        add(alapterField);

        JLabel szobakLabel = new JLabel("Szobák száma:");
        szobakField = new JTextField();
        add(szobakLabel);
        add(szobakField);

        JLabel arLabel = new JLabel("Ár:");
        arField = new JTextField();
        add(arLabel);
        add(arField);

        JLabel statuszLabel = new JLabel("Státusz:");
        statuszField = new JTextField();
        add(statuszLabel);
        add(statuszField);
        
        JLabel parkoloLabel = new JLabel("Parkoló:");
        parkoloField = new JTextField();
        add(parkoloLabel);
        add(parkoloField);
        
        JLabel emeletLabel = new JLabel("Emelet:");
        emeletField = new JTextField();
        add(emeletLabel);
        add(emeletField);
        
        JLabel erkelyLabel = new JLabel("Erkély:");
        erkelyField = new JTextField();
        add(erkelyLabel);
        add(erkelyField);
        
        JLabel szintekLabel = new JLabel("Szintek:");
        szintekField = new JTextField();
        add(szintekLabel);
        add(szintekField);
        
        JLabel telekLabel = new JLabel("Telek:");
        telekField = new JTextField();
        add(telekLabel);
        add(telekField);

        JButton uploadButton = new JButton("Feltöltés");
        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Adatok lekérése a mezőkből
                int refszam = Integer.parseInt(refszamField.getText());
                String tipus = tipusField.getText();
                String telepules = telepulesField.getText();
                int alapter = Integer.parseInt(alapterField.getText());
                int szobak = Integer.parseInt(szobakField.getText());
                int ar = Integer.parseInt(arField.getText());
                String statusz = statuszField.getText();
                // Új adat beszúrása az adatbázisba
                insertData(refszam, tipus, telepules, alapter, szobak, ar, statusz);
                // Visszalépés az első oldalra és táblázat frissítése
                cardLayout.show(cardPanel, "table");
                mainApp.addDataFromDatabase(); // Frissítsük a táblát
            }
        });
        add(uploadButton);

        JButton homeButton = new JButton("Home");
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "table"); // Az első oldalra váltás
            }
        });
        add(homeButton);
    }

    // Adatok beszúrása az adatbázisba
    private void insertData(int refszam, String tipus, String telepules, int alapter, int szobak, int ar, String statusz) {
        try {
            Connection connection = connect();
            String query = "INSERT INTO ingatlanok (refszam, tipus, telepules, alapter_nm, szobak, ar, statusz) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, refszam);
            statement.setString(2, tipus);
            statement.setString(3, telepules);
            statement.setInt(4, alapter);
            statement.setInt(5, szobak);
            statement.setInt(6, ar);
            statement.setString(7, statusz);
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Kapcsolódik az adatbázishoz, ezt már itt tartalmazza a főosztály
    private Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/real_estate"; // JDBC URL
        String user = "root"; // XAMPP alapértelmezett felhasználóneve
        String password = ""; // XAMPP alapértelmezett jelszava (nekünk most nem jelszóvédett)
        return DriverManager.getConnection(url, user, password);
    }
}

