package the.rea5_3;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Rea5_3 {
    private JFrame frame;
    private JPanel cardPanel;
    private CardLayout cardLayout;
    private DefaultTableModel model;

    public Rea5_3() {
        frame = new JFrame("REA - Ingatlankezelő rendszer");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(800, 600));

        cardPanel = new JPanel();
        cardLayout = new CardLayout();
        cardPanel.setLayout(cardLayout);

        // Táblázat inicializálása és konfigurálása
        JTable table = new JTable();
        model = new DefaultTableModel(new Object[]{"Refszám", "Típus", "Település", "Alapterület", "Szobák száma", "Ár", "Státusz"}, 0){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Minden cella nem szerkeszthető
            }
        };
        table.setModel(model);

        // Hozzáadjuk a táblázatot a kártyapanelhez
        cardPanel.add(new JScrollPane(table), "table");

        frame.add(cardPanel, BorderLayout.CENTER);

        createAndShowGUI();
    }

    private void createAndShowGUI() {
        JPanel buttonPanel = new JPanel();
        JButton uploadButton = new JButton("Feltöltés");
        JButton searchButton = new JButton("Keresés");

        buttonPanel.add(uploadButton);
        buttonPanel.add(searchButton);

        // UploadPage hozzáadása a kártyapanelhez
        UploadPage uploadPage = new UploadPage(cardLayout, cardPanel, this);
        cardPanel.add(uploadPage, "upload");

        // SearchPage hozzáadása a kártyapanelhez
        SearchPage searchPage = new SearchPage(cardLayout, cardPanel);
        cardPanel.add(searchPage, "search");

        frame.add(buttonPanel, BorderLayout.NORTH);

        // Feltöltés gombra kattintás eseménykezelése
        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "upload");
            }
        });

        // Keresés gombra kattintás eseménykezelése
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "search");
            }
        });

        // Frame beállítása és megjelenítése
        frame.pack();
        frame.setVisible(true);
    }

    // Kapcsolódik az adatbázishoz és megpróbálja lekérdezni az "ingatlanok" tábla összes sorát, majd hozzáadja ezeket a sorokat a táblázathoz.
    protected void addDataFromDatabase() {
        // Töröljük a táblázat összes sorát
        model.setRowCount(0);

        try {
            Connection connection = connect();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM ingatlanok");

            while (resultSet.next()) {
                int refszam = resultSet.getInt("refszam");
                String tipus = resultSet.getString("tipus");
                String telepules = resultSet.getString("telepules");
                int alapter_nm = resultSet.getInt("alapter_nm");
                int szobak = resultSet.getInt("szobak");
                int ar = resultSet.getInt("ar");
                String statusz = resultSet.getString("statusz");

                model.addRow(new Object[]{refszam, tipus, telepules, alapter_nm, szobak, ar, statusz});
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    // Kapcsolódik az adatbázishoz, ezt már itt tartalmazza a főosztály
    private Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/real_estate"; // JDBC URL
        String user = "root"; // XAMPP alapértelmezett felhasználóneve
        String password = ""; // XAMPP alapértelmezett jelszava (nekünk most nem jelszóvédett)
        return DriverManager.getConnection(url, user, password);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Rea5_3 app = new Rea5_3();
            app.addDataFromDatabase();
        });
    }
}

