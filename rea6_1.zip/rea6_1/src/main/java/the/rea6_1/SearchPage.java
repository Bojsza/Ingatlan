package the.rea6_1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchPage extends JPanel {
    private JTextField refszamField;
    private JTextField tipusField;
    private JTextField telepulesField;
    private JTextField alapterField;
    private JTextField szobakField;
    private JTextField arField;
    private JTextField statuszField;
    private JTextField parkoloField;
    private JTextField emeletField;
    private JTextField erkelyField;
    private JTextField szintekField;
    private JTextField telekField;

    public SearchPage(CardLayout cardLayout, JPanel cardPanel) {
        
        setLayout(new GridLayout(8, 2)); // 8 sor, 2 oszlop

        JLabel refszamLabel = new JLabel("Refszám:");
        refszamField = new JTextField();
        add(refszamLabel);
        add(refszamField);

        JLabel tipusLabel = new JLabel("Típus:");
        tipusField = new JTextField();
        add(tipusLabel);
        add(tipusField);

        JLabel telepulesLabel = new JLabel("Település:");
        telepulesField = new JTextField();
        add(telepulesLabel);
        add(telepulesField);

        JLabel alapterLabel = new JLabel("Alapterület:");
        alapterField = new JTextField();
        add(alapterLabel);
        add(alapterField);

        JLabel szobakLabel = new JLabel("Szobák száma:");
        szobakField = new JTextField();
        add(szobakLabel);
        add(szobakField);

        JLabel arLabel = new JLabel("Ár:");
        arField = new JTextField();
        add(arLabel);
        add(arField);

        JLabel statuszLabel = new JLabel("Státusz:");
        statuszField = new JTextField();
        add(statuszLabel);
        add(statuszField);
        
        JLabel parkoloLabel = new JLabel("Parkoló:");
        parkoloField = new JTextField();
        add(parkoloLabel);
        add(parkoloField);
        
        JLabel emeletLabel = new JLabel("Emelet:");
        emeletField = new JTextField();
        add(emeletLabel);
        add(emeletField);
        
        JLabel erkelyLabel = new JLabel("Erkély:");
        erkelyField = new JTextField();
        add(erkelyLabel);
        add(erkelyField);
        
        JLabel szintekLabel = new JLabel("Szintek:");
        szintekField = new JTextField();
        add(szintekLabel);
        add(szintekField);
        
        JLabel telekLabel = new JLabel("Telek:");
        telekField = new JTextField();
        add(telekLabel);
        add(telekField);

        JButton searchButton = new JButton("Keresés");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ide írd meg a keresésii logikát
                // Például: adatok lekérése a mezőkből és adatbázisba mentés
            }
        });
        add(searchButton);

        JButton homeButton = new JButton("Home");
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "table"); // Az első oldalra váltás
            }
        });
        add(homeButton);
    }
}