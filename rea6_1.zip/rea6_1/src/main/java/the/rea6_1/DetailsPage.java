package the.rea6_1;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DetailsPage extends JPanel {
    private int refszam;
    private Rea6_1 rea6;
    private JTable table;
    private DefaultTableModel model;

    public DetailsPage(int refszam, Rea6_1 rea6) {
        this.refszam = refszam;
        this.rea6 = rea6;
        setLayout(new BorderLayout());

        model = new DefaultTableModel();
        table = new JTable(model);

        // Oszlopnevek hozzáadása a modellhez
        model.addColumn("Adat");
        model.addColumn("Érték");

        try {
            Connection connection = connect();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM ingatlanok WHERE refszam = " + refszam);

            if (resultSet.next()) {
                addRow(model, "Referenciaszám", resultSet.getString("refszam"));
                addRow(model, "Típus", resultSet.getString("tipus"));
                addRow(model, "Település", resultSet.getString("telepules"));
                addRow(model, "Alapterület", resultSet.getString("alapter_nm"));
                addRow(model, "Szobák száma", resultSet.getString("szobak"));
                addRow(model, "Ár", resultSet.getString("ar"));
                addRow(model, "Parkoló", resultSet.getString("parkolo"));
                addRow(model, "Emelet", resultSet.getString("emelet"));
                addRow(model, "Erkély száma", resultSet.getString("erkely_nm"));
                addRow(model, "Szintek", resultSet.getString("szintek"));
                addRow(model, "Telek mérete", resultSet.getString("telek_nm"));
                addRow(model, "Leírás", resultSet.getString("leiras"));
                addRow(model, "Státusz", resultSet.getString("statusz"));
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        add(new JScrollPane(table), BorderLayout.CENTER);

        // Gombok hozzáadása a panelhez
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton editButton = new JButton("Szerkesztés");
        JButton statusButton = new JButton("Státusz váltás");
        buttonPanel.add(editButton);
        buttonPanel.add(statusButton);
        add(buttonPanel, BorderLayout.NORTH);

        // Home gomb hozzáadása a panelhez
        JButton homeButton = new JButton("Vissza a kezdő oldalra");
        homeButton.addActionListener(e -> {
            // Ide jöhet a kód, ami visszavisz az első oldalra
            CardLayout cardLayout = (CardLayout) getParent().getLayout();
            cardLayout.show(getParent(), "table");
            rea6.addDataFromDatabase();
        });

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(homeButton, BorderLayout.SOUTH);
        add(bottomPanel, BorderLayout.SOUTH);

        // Státuszváltás gomb eseménykezelése
        statusButton.addActionListener(e -> {
            String[] options = {"Eladó", "Eladva", "Ügyintézés alatt"};
            String selectedStatus = (String) JOptionPane.showInputDialog(
                    null,
                    "Válasszon új státuszt:",
                    "Státusz váltás",
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (selectedStatus != null) {
                updateStatus(selectedStatus);
            }
        });
    }

    // Segédfüggvény az adatok hozzáadásához a táblázathoz
    private void addRow(DefaultTableModel model, String label, String value) {
        model.addRow(new Object[]{label, value});
    }

    // Adatbázis frissítése az új státusszal
    private void updateStatus(String newStatus) {
        try {
            Connection connection = connect();
            PreparedStatement preparedStatement = connection.prepareStatement("UPDATE ingatlanok SET statusz = ? WHERE refszam = ?");
            preparedStatement.setString(1, newStatus);
            preparedStatement.setInt(2, refszam);
            preparedStatement.executeUpdate();

            // Frissítjük a táblázatot az új adatokkal
            model.setValueAt(newStatus, model.getRowCount() - 1, 1);

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/real_estate"; // JDBC URL
        String user = "root"; // XAMPP alapértelmezett felhasználóneve
        String password = ""; // XAMPP alapértelmezett jelszava (nekünk most nem jelszóvédett)
        return DriverManager.getConnection(url, user, password);
    }
}
