package the.rea6_3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchPage extends JPanel {
    private JComboBox<String> tipusField;
    private JTextField minAlapterField;
    private JTextField maxAlapterField;
    private JTextField minSzobakField;
    private JTextField maxSzobakField;
    private JTextField minArField;
    private JTextField maxArField;
    private JComboBox<String> statuszField;
    private JComboBox<String> parkoloField;
    private JComboBox<String> emeletField;
    private JTextField minErkelyField;
    private JTextField maxErkelyField;
    private JTextField minSzintekField;
    private JTextField maxSzintekField;
    private JTextField minTelekField;
    private JTextField maxTelekField;
    
    

    public SearchPage(CardLayout cardLayout, JPanel cardPanel) {

        setLayout(new GridLayout(18,2 )); // 18 sor, 2oszlop
        
       
        
        // Típus
        JLabel tipusLabel = new JLabel("Típus:");
        tipusField = new JComboBox<>(new String[]{"minden", "ház", "lakás"});
        add(tipusLabel);
        add(tipusField);

        // Alapterület
        JLabel alapterLabel = new JLabel("Alapterület:");
        minAlapterField = new JTextField();
        setPlaceholder(minAlapterField, "minimum nm");
        maxAlapterField = new JTextField();
        setPlaceholder(maxAlapterField, "maximum nm");
        add(alapterLabel);
        add(new JPanel());
        add(minAlapterField);
        add(maxAlapterField);
        
        // Szobák száma
        JLabel szobakLabel = new JLabel("Szobák száma:");
        minSzobakField = new JTextField();
        setPlaceholder(minSzobakField, "minimum szobaszám");
        maxSzobakField = new JTextField();
        setPlaceholder(maxSzobakField, "maximum szobaszám");
        add(szobakLabel);
        add(new JPanel()); 
        add(minSzobakField);
        add(maxSzobakField);

        // Ár
        JLabel arLabel = new JLabel("Ár:");
        minArField = new JTextField();
        setPlaceholder(minArField, "minimum ár");
        maxArField = new JTextField();
        setPlaceholder(maxArField, "maximum ár");
        add(arLabel);
        add(new JPanel());
        add(minArField);
        add(maxArField);

        // Státusz
        JLabel statuszLabel = new JLabel("Státusz:");
        statuszField = new JComboBox<>(new String[]{"minden", "eladó", "eladva", "ügyintézés alatt"});
        add(statuszLabel);
        add(statuszField);

        // Parkoló
        JLabel parkoloLabel = new JLabel("Parkoló:");
        parkoloField = new JComboBox<>(new String[]{"minden", "nincs","bármilyen parkolóval", "udvari beálló", "utca", "közterület", "önálló garázs" });
        add(parkoloLabel);
        add(parkoloField);

        // Emelet
        JLabel emeletLabel = new JLabel("Emelet:");
        emeletField = new JComboBox<>(new String[]{"minden","1 vagy alatta ", "2 vagy fölötte", "szuterén", "földszint", "félemelet", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "10 fölötti emeletek"});
        add(emeletLabel);
        add(emeletField);

        // Erkély
        JLabel erkelyLabel = new JLabel("Erkély mérete:");
        minErkelyField = new JTextField();
        setPlaceholder(minErkelyField, "minimum nm");
        maxErkelyField = new JTextField();
        setPlaceholder(maxErkelyField, "maximum nm");
        add(erkelyLabel);
        add(new JPanel());
        add(minErkelyField);
        add(maxErkelyField);

        // Szintek
        JLabel szintekLabel = new JLabel("Épület szintjeinek száma:");
        minSzintekField = new JTextField();
        setPlaceholder(minSzintekField, "minimum szintek száma");
        maxSzintekField = new JTextField();
        setPlaceholder(maxSzintekField, "maximum szintek száma");
        add(szintekLabel);
        add(new JPanel());
        add(minSzintekField);
        add(maxSzintekField);

        // Telek
        JLabel telekLabel = new JLabel("Telek:");
        minTelekField = new JTextField();
        setPlaceholder(minTelekField, "minimum telek nm");

        maxTelekField = new JTextField();
        setPlaceholder(maxTelekField, "maximum telek nm");
        add(telekLabel);
        add(new JPanel());
        add(minTelekField);
        add(maxTelekField);

        // Keresés gomb és eseménykezelője régi cucc
        JButton searchButton = new JButton("Keresés az adatbázisban");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Ide írd meg a keresésii logikát
                // Például: adatok lekérése a mezőkből és adatbázisba mentés
            }
        });
        add(searchButton);
        
        // Home gomb és eseménykezelője
        JButton homeButton = new JButton("Vissza a kezdő oldalra");
        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, "table"); // Az első oldalra váltás
            }
        });
        add(homeButton);
    }

    
    // Placeholder beállítása JTextField-hez
    private void setPlaceholder(JTextField textField, String placeholder) {
        textField.setForeground(Color.GRAY);
        textField.setText(placeholder);
        textField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textField.getText().equals(placeholder)) {
                    textField.setText("");
                    textField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textField.getText().isEmpty()) {
                    textField.setForeground(Color.GRAY);
                    textField.setText(placeholder);
                }
            }
        });
    }
}
